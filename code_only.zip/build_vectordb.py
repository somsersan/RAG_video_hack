"""
Video-RAG pipeline: scene detection → ASR → embeddings → FAISS DB.

Visual embeddings:  SigLIP2 (google/siglip2-large-patch16-384)
                    3 keyframes per scene, mean-pooled → visual.index
Text embeddings:    BGE-M3  (BAAI/bge-m3)
                    cleaned transcript → CLS-pooled  → text.index

Run:
    python build_vectordb.py

Options:
    --data_dir        Directory with .mp4 files            [data]
    --output_dir      Intermediate artefacts (keyframes, scenes JSON) [output]
    --db_dir          Final FAISS + metadata output        [db]
    --scene_threshold ContentDetector threshold            [27.0]
    --min_scene_len   Min scene length in frames           [15]
    --keyframe_method Keyframe extraction strategy         [fixed3]
    --sample_fps      Uniform sampling FPS (new method)    [1.0]
    --keyframes_per_scene Representatives per scene        [3]
    --cluster_model   HF model for frame embeddings        [openai/clip-vit-base-patch32]
    --cluster_batch   Batch size for frame embedding       [16]
    --cluster_seed    Random seed for k-means++            [42]
    --cluster_verbose Detailed logs for kmeans++ selection  [False]
    --hf_cache_dir    HuggingFace cache directory           [.model_cache/hf]
    --offline_models  Load models only from local cache     [False]
    --whisper_model   faster-whisper size: tiny|base|small [base]
    --language        Whisper language code or None        [None = auto]
    --device          "cpu" or "cuda"                      [cpu]
    --img_batch       Batch size for image embedding       [8]
    --txt_batch       Batch size for text embedding        [32]
    --skip_asr        Skip ASR step (useful for re-runs)   [False]
    --skip_scenes     Reuse existing output/all_scenes.json[False]
"""

import json
import argparse
import traceback
from pathlib import Path

import torch

from src.scene_detect import detect_scenes, ClipFrameEmbedder
from src.asr import transcribe_video
from src.embed import (
    load_visual_model,
    load_text_model,
    build_all_visual_embeddings,
    build_all_text_embeddings,
    save_db,
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Build Video-RAG FAISS vector database",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--data_dir",        default="data")
    p.add_argument("--output_dir",      default="output")
    p.add_argument("--db_dir",          default="db")
    p.add_argument("--scene_threshold", type=float, default=27.0)
    p.add_argument("--min_scene_len",   type=int,   default=15)
    p.add_argument(
        "--keyframe_method",
        default="fixed3",
        choices=["fixed3", "uniform_clip_kmeans"],
        help="Keyframe extraction strategy",
    )
    p.add_argument("--sample_fps", type=float, default=1.0,
                   help="Candidate frame sampling FPS for uniform_clip_kmeans")
    p.add_argument("--keyframes_per_scene", type=int, default=3,
                   help="Representative keyframes per scene for uniform_clip_kmeans")
    p.add_argument("--cluster_model", default="openai/clip-vit-base-patch32",
                   help="HF model id for frame embeddings in uniform_clip_kmeans")
    p.add_argument("--cluster_batch", type=int, default=16,
                   help="Batch size for frame embedding model in uniform_clip_kmeans")
    p.add_argument("--cluster_seed", type=int, default=42,
                   help="Random seed for k-means++ in uniform_clip_kmeans")
    p.add_argument("--cluster_verbose", action="store_true",
                   help="Print detailed logs for kmeans++ keyframe selection")
    p.add_argument("--hf_cache_dir", default=".model_cache/hf",
                   help="Local cache dir for HuggingFace models")
    p.add_argument("--offline_models", action="store_true",
                   help="Load models from local cache only (no internet downloads)")
    p.add_argument("--whisper_model",   default="base",
                   choices=["tiny", "base", "small", "medium", "large-v3"])
    p.add_argument("--language",        default=None,
                   help="ISO-639-1 code, e.g. 'ru'. None = auto-detect.")
    p.add_argument("--device",          default="auto", choices=["auto", "cpu", "cuda", "mps"])
    p.add_argument("--img_batch",       type=int, default=8)
    p.add_argument("--txt_batch",       type=int, default=32)
    p.add_argument("--skip_asr",        action="store_true",
                   help="Skip ASR; use transcript='' for all scenes.")
    p.add_argument("--skip_scenes",     action="store_true",
                   help="Reuse output/all_scenes.json if it exists.")
    return p.parse_args()


def _resolve_requested_device(requested: str) -> str:
    """Resolve requested device to an available torch device."""
    if requested == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        return "cpu"

    if requested == "cuda" and not torch.cuda.is_available():
        print("  [device] CUDA requested but unavailable. Falling back to CPU.")
        return "cpu"

    if requested == "mps":
        mps_ok = hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
        if not mps_ok:
            print("  [device] MPS requested but unavailable. Falling back to CPU.")
            return "cpu"

    return requested


def _resolve_stage_devices(requested: str) -> dict[str, str]:
    """
    Resolve per-stage devices:
      - frame_embed: keyframe selection model (Transformers)
      - index_embed: visual/text embedding models (Transformers)
      - asr: faster-whisper (ctranslate2; no MPS support => CPU fallback)
    """
    base = _resolve_requested_device(requested)
    asr_device = "cuda" if base == "cuda" else "cpu"
    return {
        "frame_embed": base,
        "index_embed": base,
        "asr": asr_device,
    }


def main() -> None:
    args = parse_args()
    stage_device = _resolve_stage_devices(args.device)

    data_dir   = Path(args.data_dir)
    output_dir = Path(args.output_dir)
    db_dir     = Path(args.db_dir)
    scenes_json = output_dir / "all_scenes.json"

    video_files = sorted(data_dir.glob("*.mp4"))
    if not video_files:
        raise FileNotFoundError(f"No .mp4 files found in '{data_dir}'")
    print(f"Found {len(video_files)} video(s): {[v.name for v in video_files]}")
    print(
        "Resolved devices: "
        f"frame_embed={stage_device['frame_embed']}, "
        f"index_embed={stage_device['index_embed']}, "
        f"asr={stage_device['asr']}"
    )

    # ── Step 1 : Scene detection ─────────────────────────────────────────────
    if args.skip_scenes and scenes_json.exists():
        print(f"\n[1/3] Reusing existing scenes: {scenes_json}")
        with open(scenes_json, encoding="utf-8") as f:
            all_scenes = json.load(f)
    else:
        print("\n[1/3] Detecting scenes …")
        all_scenes = []
        shared_cluster_embedder: ClipFrameEmbedder | None = None
        if args.keyframe_method == "uniform_clip_kmeans":
            print(
                "  Preloading frame-selection model once for all videos "
                f"({args.cluster_model}, device={stage_device['frame_embed']}) …"
            )
            shared_cluster_embedder = ClipFrameEmbedder(
                model_name=args.cluster_model,
                device=stage_device["frame_embed"],
                batch_size=args.cluster_batch,
                cache_dir=args.hf_cache_dir,
                local_files_only=args.offline_models,
            )
        for vp in video_files:
            scenes = detect_scenes(
                str(vp), str(output_dir),
                threshold=args.scene_threshold,
                min_scene_len=args.min_scene_len,
                keyframe_method=args.keyframe_method,
                sample_fps=args.sample_fps,
                keyframes_per_scene=args.keyframes_per_scene,
                cluster_model=args.cluster_model,
                cluster_device=stage_device["frame_embed"],
                cluster_batch=args.cluster_batch,
                cluster_seed=args.cluster_seed,
                cluster_verbose=args.cluster_verbose,
                hf_cache_dir=args.hf_cache_dir,
                offline_models=args.offline_models,
                cluster_embedder=shared_cluster_embedder,
            )
            all_scenes.extend(scenes)

        output_dir.mkdir(parents=True, exist_ok=True)
        with open(scenes_json, "w", encoding="utf-8") as f:
            json.dump(all_scenes, f, ensure_ascii=False, indent=2)
        print(f"  Total: {len(all_scenes)} scenes → {scenes_json}")

    print(f"  Scenes in memory: {len(all_scenes)} (from {len(video_files)} video(s))")

    # ── Step 2 : ASR ────────────────────────────────────────────────────────
    if args.skip_asr:
        print("\n[2/3] Skipping ASR (--skip_asr)")
    else:
        print("\n[2/3] Transcribing audio …")
        for i, vp in enumerate(video_files, 1):
            video_scenes = [s for s in all_scenes if s["video"] == vp.name]
            if not video_scenes:
                print(f"  [{vp.name}] No scenes found, skipping")
                continue
            print(f"  ({i}/{len(video_files)}) Processing {vp.name} — {len(video_scenes)} scenes")
            try:
                transcribe_video(
                    str(vp), video_scenes,
                    model_size=args.whisper_model,
                    language=args.language,
                    device=stage_device["asr"],
                )
            except Exception:
                print(f"  ERROR transcribing {vp.name}, skipping:")
                traceback.print_exc()
                continue

            # Save after every video so partial results are never lost
            with open(scenes_json, "w", encoding="utf-8") as f:
                json.dump(all_scenes, f, ensure_ascii=False, indent=2)
            filled = sum(1 for s in all_scenes if s.get("transcript"))
            print(f"  Checkpoint saved → {scenes_json} ({filled}/{len(all_scenes)} scenes with text)")

    # ── Step 3 : Embeddings + FAISS ──────────────────────────────────────────
    print("\n[3/3] Building embeddings and FAISS index …")
    print("  Loading visual model (SigLIP2) …")
    vis_model, vis_proc = load_visual_model(
        stage_device["index_embed"],
        cache_dir=args.hf_cache_dir,
        local_files_only=args.offline_models,
    )
    print("  Loading text model (BGE-M3) …")
    txt_model, txt_tok  = load_text_model(
        stage_device["index_embed"],
        cache_dir=args.hf_cache_dir,
        local_files_only=args.offline_models,
    )

    print(f"  Encoding {len(all_scenes)} scenes (visual) …")
    vis_embs = build_all_visual_embeddings(
        all_scenes, vis_model, vis_proc, stage_device["index_embed"]
    )

    print(f"  Encoding {len(all_scenes)} scenes (text) …")
    txt_embs = build_all_text_embeddings(
        all_scenes, txt_model, txt_tok, stage_device["index_embed"], args.txt_batch
    )

    save_db(all_scenes, vis_embs, txt_embs, str(db_dir))

    print("\n✓ Done! Run `python search.py --query \"<your query>\"` to test retrieval.")


if __name__ == "__main__":
    main()
