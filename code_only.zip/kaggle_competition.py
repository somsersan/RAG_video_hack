"""
Kaggle baseline pipeline for the Multi-lingual Video Fragment Retrieval challenge.

Pipeline:
1) Detect scenes in videos (PySceneDetect)
2) Extract keyframes using --keyframe_method (recommended: uniform_clip_kmeans)
3) Attach transcript segments from transcripts.pkl to detected scenes by time overlap
4) Build text embeddings + FAISS index
5) Run retrieval for test.csv queries and save submission
"""

from __future__ import annotations

import argparse
import os
import pickle
import sys
from pathlib import Path, PurePosixPath
from typing import Any

import faiss
import numpy as np
import pandas as pd
import torch

from src.embed import (
    build_all_text_embeddings,
    embed_texts_bge,
    load_text_model,
    save_db,
)
from src.scene_detect import detect_scenes, SUPPORTED_KEYFRAME_METHODS


DEFAULT_TRANSCRIPTS = (
    "/kaggle/input/competitions/"
    "multi-lingual-video-fragment-retrieval-challenge/video-rag/transcripts.pkl"
)
DEFAULT_TEST_CSV = (
    "/kaggle/input/competitions/"
    "multi-lingual-video-fragment-retrieval-challenge/video-rag/test/test.csv"
)
DEFAULT_VIDEOS_DIR = (
    "/kaggle/input/competitions/"
    "multi-lingual-video-fragment-retrieval-challenge/video-rag/videos"
)
DEFAULT_OUTPUT_DIR = "/kaggle/working/ai-chemp-cu-itmo/competition_run"


VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Scene detect + keyframes + transcript indexing for Kaggle test.csv"
    )
    p.add_argument("--transcripts_pkl", default=DEFAULT_TRANSCRIPTS)
    p.add_argument("--test_csv", default=DEFAULT_TEST_CSV)
    p.add_argument("--videos_dir", default=DEFAULT_VIDEOS_DIR)
    p.add_argument("--output_dir", default=DEFAULT_OUTPUT_DIR)

    # Scene detection + keyframe extraction
    p.add_argument("--scene_threshold", type=float, default=27.0)
    p.add_argument("--min_scene_len", type=int, default=15)
    p.add_argument(
        "--keyframe_method",
        default="uniform_clip_kmeans",
        choices=list(SUPPORTED_KEYFRAME_METHODS),
        help="Keyframe extraction method",
    )
    p.add_argument("--sample_fps", type=float, default=1.0)
    p.add_argument("--keyframes_per_scene", type=int, default=3)
    p.add_argument("--cluster_model", default="openai/clip-vit-base-patch32")
    p.add_argument("--cluster_batch", type=int, default=16)
    p.add_argument("--cluster_seed", type=int, default=42)
    p.add_argument("--cluster_verbose", action="store_true")

    # Embeddings / retrieval
    p.add_argument("--top_k", type=int, default=5, help="Top-K retrieval for debug CSV")
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda", "mps"])
    p.add_argument(
        "--hf_cache_dir",
        default="/kaggle/working/.model_cache/hf",
        help="HuggingFace cache directory",
    )
    p.add_argument(
        "--offline_models",
        action="store_true",
        help="Load HF models from cache only",
    )
    p.add_argument("--txt_batch", type=int, default=128, help="Batch size for transcript embedding")
    p.add_argument("--query_batch", type=int, default=128, help="Batch size for query embedding")
    p.add_argument(
        "--submission_video_col",
        default="video",
        help="Output column name for predicted video",
    )
    p.add_argument(
        "--submission_start_col",
        default="start_sec",
        help="Output column name for predicted start timestamp",
    )
    p.add_argument(
        "--submission_end_col",
        default="end_sec",
        help="Output column name for predicted end timestamp",
    )
    args, _unknown = p.parse_known_args(argv)
    return args


def resolve_device(requested: str) -> str:
    if requested == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    if requested == "cuda" and not torch.cuda.is_available():
        print("[device] CUDA requested but unavailable. Falling back to CPU.")
        return "cpu"
    if requested == "mps":
        has_mps = hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
        if not has_mps:
            print("[device] MPS requested but unavailable. Falling back to CPU.")
            return "cpu"
    return requested


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _discover_videos(videos_dir: Path) -> list[Path]:
    files = [
        p for p in videos_dir.iterdir()
        if p.is_file() and p.suffix.lower() in VIDEO_EXTS
    ]
    return sorted(files)


def _build_transcript_map(transcripts: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    """Map video stem -> transcript segments (sorted by start time)."""
    by_stem: dict[str, list[dict[str, Any]]] = {}
    for raw_key, segments in transcripts.items():
        if not isinstance(segments, list):
            continue
        key_name = PurePosixPath(str(raw_key)).name
        stem = Path(key_name).stem

        cleaned: list[dict[str, Any]] = []
        for seg in segments:
            if not isinstance(seg, dict):
                continue
            start = _to_float(seg.get("start"), 0.0)
            end = _to_float(seg.get("end"), start)
            if end <= start:
                continue
            text = str(seg.get("text") or "").strip()
            cleaned.append({"start": start, "end": end, "text": text})

        cleaned.sort(key=lambda x: (x["start"], x["end"]))
        by_stem[stem] = cleaned
    return by_stem


def _attach_transcript_to_scenes(
    scenes: list[dict[str, Any]],
    transcript_segments: list[dict[str, Any]],
) -> None:
    """Fill scene['transcript'] by overlap with transcript segments."""
    for scene in scenes:
        s_start = _to_float(scene.get("start_sec"), 0.0)
        s_end = _to_float(scene.get("end_sec"), s_start)
        matched = [
            seg["text"]
            for seg in transcript_segments
            if seg["start"] < s_end and seg["end"] > s_start and seg["text"]
        ]
        merged = " ".join(matched).strip()
        scene["transcript"] = merged
        scene["transcript_text"] = merged


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    device = resolve_device(args.device)

    transcripts_pkl = Path(args.transcripts_pkl)
    test_csv = Path(args.test_csv)
    videos_dir = Path(args.videos_dir)
    output_dir = Path(args.output_dir)
    db_dir = output_dir / "db"
    output_dir.mkdir(parents=True, exist_ok=True)
    db_dir.mkdir(parents=True, exist_ok=True)

    if not transcripts_pkl.exists():
        raise FileNotFoundError(f"transcripts.pkl not found: {transcripts_pkl}")
    if not test_csv.exists():
        raise FileNotFoundError(f"test.csv not found: {test_csv}")
    if not videos_dir.exists():
        raise FileNotFoundError(f"videos_dir not found: {videos_dir}")

    print("== Kaggle competition pipeline ==")
    print(f"  transcripts: {transcripts_pkl}")
    print(f"  test.csv:    {test_csv}")
    print(f"  videos_dir:  {videos_dir}")
    print(f"  output_dir:  {output_dir}")
    print(f"  device:      {device}")

    print("\n[1/5] Loading transcripts.pkl ...")
    with open(transcripts_pkl, "rb") as f:
        transcripts = pickle.load(f)
    if not isinstance(transcripts, dict):
        raise TypeError(f"Expected dict in transcripts.pkl, got {type(transcripts)}")
    transcript_map = _build_transcript_map(transcripts)
    print(f"  Transcript keys: {len(transcript_map)}")

    print("\n[2/5] Detecting scenes + extracting keyframes ...")
    videos = _discover_videos(videos_dir)
    if not videos:
        raise RuntimeError(f"No video files found in {videos_dir}")
    print(f"  Videos found: {len(videos)}")

    all_scenes: list[dict[str, Any]] = []
    for idx, video_path in enumerate(videos, 1):
        print(f"  ({idx}/{len(videos)}) {video_path.name}")
        scenes = detect_scenes(
            video_path=str(video_path),
            output_dir=str(output_dir),
            threshold=args.scene_threshold,
            min_scene_len=args.min_scene_len,
            keyframe_method=args.keyframe_method,
            sample_fps=args.sample_fps,
            keyframes_per_scene=args.keyframes_per_scene,
            cluster_model=args.cluster_model,
            cluster_device=device,
            cluster_batch=args.cluster_batch,
            cluster_seed=args.cluster_seed,
            hf_cache_dir=args.hf_cache_dir,
            offline_models=args.offline_models,
            cluster_verbose=args.cluster_verbose,
        )

        transcript_segments = transcript_map.get(video_path.stem, [])
        _attach_transcript_to_scenes(scenes, transcript_segments)

        filled = sum(1 for s in scenes if s.get("transcript"))
        print(f"    transcript coverage: {filled}/{len(scenes)}")
        all_scenes.extend(scenes)

    if not all_scenes:
        raise RuntimeError("No scenes produced from videos")
    print(f"  Total scenes: {len(all_scenes)}")

    print("\n[3/5] Building embeddings + FAISS index ...")
    text_model, text_tok = load_text_model(
        device=device,
        cache_dir=args.hf_cache_dir,
        local_files_only=args.offline_models,
    )
    text_embs = build_all_text_embeddings(
        all_scenes,
        model=text_model,
        tokenizer=text_tok,
        device=device,
        batch_size=args.txt_batch,
    )

    # For compatibility with existing load_db/search interfaces.
    save_db(
        scenes=all_scenes,
        visual_embeddings=text_embs,
        text_embeddings=text_embs,
        output_dir=str(db_dir),
    )
    txt_index = faiss.read_index(str(db_dir / "text.index"))

    print("\n[4/5] Running retrieval for test.csv ...")
    df_test = pd.read_csv(test_csv)
    missing_cols = {"query_id", "question"} - set(df_test.columns)
    if missing_cols:
        raise ValueError(f"test.csv missing columns: {sorted(missing_cols)}")

    queries = df_test["question"].fillna("").astype(str).tolist()
    query_embs = embed_texts_bge(
        texts=queries,
        model=text_model,
        tokenizer=text_tok,
        device=device,
        batch_size=args.query_batch,
    )
    query_embs = query_embs.astype(np.float32, copy=False)

    top_k = max(1, min(args.top_k, txt_index.ntotal))
    scores, ids = txt_index.search(query_embs, top_k)

    rows_topk: list[dict[str, Any]] = []
    rows_top1: list[dict[str, Any]] = []

    for q_idx, (_, test_row) in enumerate(df_test.iterrows()):
        qid = test_row["query_id"]
        question = str(test_row["question"])

        best = None
        for rank in range(top_k):
            fid = int(ids[q_idx, rank])
            score = float(scores[q_idx, rank])
            if fid < 0:
                continue
            scene = all_scenes[fid]
            row = {
                "query_id": qid,
                "question": question,
                "rank": rank + 1,
                "score": score,
                "faiss_id": fid,
                "video": scene["video"],
                "start_sec": float(scene["start_sec"]),
                "end_sec": float(scene["end_sec"]),
                "transcript": scene.get("transcript", ""),
            }
            rows_topk.append(row)
            if best is None:
                best = row

        if best is None:
            rows_top1.append(
                {
                    "query_id": qid,
                    args.submission_video_col: "",
                    args.submission_start_col: 0.0,
                    args.submission_end_col: 0.0,
                }
            )
        else:
            rows_top1.append(
                {
                    "query_id": qid,
                    args.submission_video_col: best["video"],
                    args.submission_start_col: best["start_sec"],
                    args.submission_end_col: best["end_sec"],
                }
            )

    print("\n[5/5] Saving outputs ...")
    retrieval_topk_path = output_dir / "retrieval_topk.csv"
    submission_path = output_dir / "submission.csv"
    pd.DataFrame(rows_topk).to_csv(retrieval_topk_path, index=False)
    pd.DataFrame(rows_top1).to_csv(submission_path, index=False)

    print("\nDone.")
    print(f"  Keyframes dir:      {output_dir / 'keyframes'}")
    print(f"  DB directory:       {db_dir}")
    print(f"  Retrieval (top-k):  {retrieval_topk_path}")
    print(f"  Submission (top-1): {submission_path}")


if __name__ == "__main__":
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    main(sys.argv[1:])
