"""
Kaggle runner:
1) build_vectordb.py
2) app.py in no-UI batch mode (top-k retrieval, no VLM by default)

Usage:
    python kaggle_full_pipeline.py --test_csv /path/to/test.csv
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run build_vectordb + headless app retrieval")

    p.add_argument("--project_dir", default=str(Path(__file__).resolve().parent))
    p.add_argument("--data_dir", default="/kaggle/input/competitions/multi-lingual-video-fragment-retrieval-challenge/video-rag/videos")
    p.add_argument("--output_dir", default="/kaggle/working/ai-chemp-cu-itmo/output")
    p.add_argument("--db_dir", default="/kaggle/working/ai-chemp-cu-itmo/db")
    p.add_argument("--test_csv", required=True)
    p.add_argument("--retrieval_csv", default="/kaggle/working/ai-chemp-cu-itmo/retrieval_top5.csv")

    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda", "mps"])
    p.add_argument("--hf_cache_dir", default="/kaggle/working/.model_cache/hf")
    p.add_argument("--offline_models", action="store_true")
    p.add_argument("--skip_asr", action="store_true")
    p.add_argument("--skip_scenes", action="store_true")

    p.add_argument("--scene_threshold", type=float, default=27.0)
    p.add_argument("--min_scene_len", type=int, default=15)
    p.add_argument("--keyframe_method", default="uniform_clip_kmeans", choices=["fixed3", "uniform_clip_kmeans"])
    p.add_argument("--sample_fps", type=float, default=1.0)
    p.add_argument("--keyframes_per_scene", type=int, default=3)
    p.add_argument("--cluster_model", default="openai/clip-vit-base-patch32")
    p.add_argument("--cluster_batch", type=int, default=16)
    p.add_argument("--cluster_seed", type=int, default=42)
    p.add_argument("--cluster_verbose", action="store_true")

    p.add_argument("--top_k", type=int, default=5)
    p.add_argument("--candidates", type=int, default=25)
    p.add_argument("--query_col", default="question")
    p.add_argument("--query_id_col", default="query_id")
    return p.parse_args()


def _run(cmd: list[str], cwd: Path) -> None:
    print("\n$ " + " ".join(cmd))
    subprocess.run(cmd, cwd=str(cwd), check=True)


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir).resolve()
    py = sys.executable

    build_cmd = [
        py, "build_vectordb.py",
        "--data_dir", args.data_dir,
        "--output_dir", args.output_dir,
        "--db_dir", args.db_dir,
        "--scene_threshold", str(args.scene_threshold),
        "--min_scene_len", str(args.min_scene_len),
        "--keyframe_method", args.keyframe_method,
        "--sample_fps", str(args.sample_fps),
        "--keyframes_per_scene", str(args.keyframes_per_scene),
        "--cluster_model", args.cluster_model,
        "--cluster_batch", str(args.cluster_batch),
        "--cluster_seed", str(args.cluster_seed),
        "--hf_cache_dir", args.hf_cache_dir,
        "--device", args.device,
    ]
    if args.offline_models:
        build_cmd.append("--offline_models")
    if args.skip_asr:
        build_cmd.append("--skip_asr")
    if args.skip_scenes:
        build_cmd.append("--skip_scenes")
    if args.cluster_verbose:
        build_cmd.append("--cluster_verbose")

    _run(build_cmd, project_dir)

    app_cmd = [
        py, "app.py",
        "--no_ui",
        "--db_dir", args.db_dir,
        "--data_dir", args.data_dir,
        "--device", args.device,
        "--top_k", str(args.top_k),
        "--candidates", str(args.candidates),
        "--queries_csv", args.test_csv,
        "--output_csv", args.retrieval_csv,
        "--query_col", args.query_col,
        "--query_id_col", args.query_id_col,
    ]
    _run(app_cmd, project_dir)

    print("\nDone.")
    print(f"Top-{args.top_k} retrieval saved to: {args.retrieval_csv}")


if __name__ == "__main__":
    main()
