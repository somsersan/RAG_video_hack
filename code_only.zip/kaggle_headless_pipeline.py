"""
Headless Kaggle pipeline:
1) Run build_vectordb.py
2) Attach transcripts.pkl segments to detected scenes
3) Rebuild text index (keep visual index from build_vectordb)
4) Run fused retriever (visual+text) without VLM, save top-k CSV
"""

from __future__ import annotations

import argparse
import json
import pickle
import subprocess
import sys
from pathlib import Path, PurePosixPath
from typing import Any

import faiss
import numpy as np
import pandas as pd
import torch

from search import search_index, weighted_reciprocal_rank_fusion
from src.embed import (
    build_all_text_embeddings,
    encode_text_query,
    encode_visual_query,
    load_db,
    load_text_model,
    load_visual_model,
    save_db,
)


DEFAULT_TRANSCRIPTS = (
    "/kaggle/input/competitions/"
    "multi-lingual-video-fragment-retrieval-challenge/video-rag/transcripts.pkl"
)
DEFAULT_TEST_CSV = (
    "/kaggle/input/competitions/"
    "multi-lingual-video-fragment-retrieval-challenge/video-rag/test/test.csv"
)
DEFAULT_VIDEOS_DIR = (
    "/kaggle/input/competitions/"
    "multi-lingual-video-fragment-retrieval-challenge/video-rag/videos"
)
DEFAULT_WORKDIR = "/kaggle/working/ai-chemp-cu-itmo"
DEFAULT_RUN_DIR = "/kaggle/working/ai-chemp-cu-itmo-run"


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Headless build_vectordb + top-k retrieval (no VLM)")
    p.add_argument("--project_dir", default=DEFAULT_WORKDIR)
    p.add_argument("--data_dir", default=DEFAULT_VIDEOS_DIR)
    p.add_argument("--transcripts_pkl", default=DEFAULT_TRANSCRIPTS)
    p.add_argument("--test_csv", default=DEFAULT_TEST_CSV)
    p.add_argument("--output_dir", default="output")
    p.add_argument("--db_dir", default="db")
    p.add_argument("--results_csv", default="competition_run/retrieval_top5.csv")
    p.add_argument("--submission_csv", default="competition_run/submission.csv")

    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda", "mps"])
    p.add_argument("--hf_cache_dir", default="/kaggle/working/.model_cache/hf")
    p.add_argument("--offline_models", action="store_true")

    # build_vectordb args
    p.add_argument("--skip_build", action="store_true")
    p.add_argument("--scene_threshold", type=float, default=27.0)
    p.add_argument("--min_scene_len", type=int, default=15)
    p.add_argument("--keyframe_method", default="uniform_clip_kmeans")
    p.add_argument("--sample_fps", type=float, default=1.0)
    p.add_argument("--keyframes_per_scene", type=int, default=3)
    p.add_argument("--cluster_model", default="openai/clip-vit-base-patch32")
    p.add_argument("--cluster_batch", type=int, default=16)
    p.add_argument("--cluster_seed", type=int, default=42)
    p.add_argument("--cluster_verbose", action="store_true")
    p.add_argument("--txt_batch", type=int, default=128)

    # retriever args
    p.add_argument("--top_k", type=int, default=5)
    p.add_argument("--candidate_k", type=int, default=30)
    p.add_argument("--query_col", default="question")
    p.add_argument("--query_id_col", default="query_id")
    p.add_argument("--visual_weight", type=float, default=0.5)
    p.add_argument("--text_weight", type=float, default=0.5)

    args, _unknown = p.parse_known_args(argv)
    return args


def resolve_device(requested: str) -> str:
    if requested == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    if requested == "cuda" and not torch.cuda.is_available():
        return "cpu"
    if requested == "mps":
        ok = hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
        return "mps" if ok else "cpu"
    return requested


def _to_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


def _resolve_project_root(project_dir: Path) -> Path:
    """
    Resolve actual project root that contains build_vectordb.py and src/.
    Handles archives unpacked with an extra nested folder.
    """
    direct_build = project_dir / "build_vectordb.py"
    direct_src = project_dir / "src"
    if direct_build.exists() and direct_src.is_dir():
        return project_dir

    candidates: list[Path] = []
    for p in project_dir.rglob("build_vectordb.py"):
        parent = p.parent
        if (parent / "src").is_dir():
            candidates.append(parent)

    if not candidates:
        raise FileNotFoundError(
            "Could not find build_vectordb.py under project_dir. "
            f"project_dir={project_dir}"
        )

    # Prefer the shallowest path (closest to provided project_dir)
    candidates.sort(key=lambda x: (len(x.relative_to(project_dir).parts), str(x)))
    return candidates[0]


def _is_relative_pathlike(value: str) -> bool:
    return not Path(value).is_absolute()


def _redirect_to_writable_if_needed(args: argparse.Namespace, project_root: Path) -> None:
    """
    If project is under /kaggle/input (read-only), remap relative output paths
    to /kaggle/working so build/index artifacts can be written.
    """
    project_str = str(project_root)
    in_readonly_kaggle_input = project_str.startswith("/kaggle/input/")
    if not in_readonly_kaggle_input:
        return

    run_root = Path(DEFAULT_RUN_DIR)
    run_root.mkdir(parents=True, exist_ok=True)

    if _is_relative_pathlike(args.output_dir):
        args.output_dir = str(run_root / args.output_dir)
    if _is_relative_pathlike(args.db_dir):
        args.db_dir = str(run_root / args.db_dir)
    if _is_relative_pathlike(args.results_csv):
        args.results_csv = str(run_root / args.results_csv)
    if _is_relative_pathlike(args.submission_csv):
        args.submission_csv = str(run_root / args.submission_csv)


def _build_transcript_map(transcripts: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    by_stem: dict[str, list[dict[str, Any]]] = {}
    for raw_key, segs in transcripts.items():
        if not isinstance(segs, list):
            continue
        stem = Path(PurePosixPath(str(raw_key)).name).stem
        cleaned: list[dict[str, Any]] = []
        for seg in segs:
            if not isinstance(seg, dict):
                continue
            start = _to_float(seg.get("start"), 0.0)
            end = _to_float(seg.get("end"), start)
            if end <= start:
                continue
            text = str(seg.get("text") or "").strip()
            cleaned.append({"start": start, "end": end, "text": text})
        cleaned.sort(key=lambda x: (x["start"], x["end"]))
        by_stem[stem] = cleaned
    return by_stem


def _attach_transcripts_to_scenes(scenes: list[dict[str, Any]], transcript_map: dict[str, list[dict[str, Any]]]) -> None:
    for scene in scenes:
        stem = Path(str(scene.get("video", ""))).stem
        segs = transcript_map.get(stem, [])
        s_start = _to_float(scene.get("start_sec"), 0.0)
        s_end = _to_float(scene.get("end_sec"), s_start)
        matched = [seg["text"] for seg in segs if seg["start"] < s_end and seg["end"] > s_start and seg["text"]]
        text = " ".join(matched).strip()
        scene["transcript"] = text
        scene["transcript_text"] = text


def run_build_vectordb(args: argparse.Namespace, project_dir: Path, device: str) -> None:
    build_script = project_dir / "build_vectordb.py"
    cmd = [
        sys.executable,
        str(build_script),
        "--data_dir",
        str(args.data_dir),
        "--output_dir",
        str(args.output_dir),
        "--db_dir",
        str(args.db_dir),
        "--scene_threshold",
        str(args.scene_threshold),
        "--min_scene_len",
        str(args.min_scene_len),
        "--keyframe_method",
        str(args.keyframe_method),
        "--sample_fps",
        str(args.sample_fps),
        "--keyframes_per_scene",
        str(args.keyframes_per_scene),
        "--cluster_model",
        str(args.cluster_model),
        "--cluster_batch",
        str(args.cluster_batch),
        "--cluster_seed",
        str(args.cluster_seed),
        "--device",
        str(device),
        "--hf_cache_dir",
        str(args.hf_cache_dir),
        "--txt_batch",
        str(args.txt_batch),
        "--skip_asr",
    ]
    if args.offline_models:
        cmd.append("--offline_models")
    if args.cluster_verbose:
        cmd.append("--cluster_verbose")

    print("[build] Running:", " ".join(cmd))
    subprocess.run(cmd, check=True, cwd=project_dir)


def rebuild_text_index_with_transcripts(
    args: argparse.Namespace,
    project_dir: Path,
    device: str,
) -> tuple[list[dict[str, Any]], Path]:
    output_dir = project_dir / args.output_dir
    db_dir = project_dir / args.db_dir
    scenes_json = output_dir / "all_scenes.json"

    if not scenes_json.exists():
        raise FileNotFoundError(f"Missing scenes json after build: {scenes_json}")
    if not Path(args.transcripts_pkl).exists():
        raise FileNotFoundError(f"transcripts.pkl not found: {args.transcripts_pkl}")

    with open(scenes_json, encoding="utf-8") as f:
        scenes = json.load(f)
    with open(args.transcripts_pkl, "rb") as f:
        transcripts = pickle.load(f)
    if not isinstance(transcripts, dict):
        raise TypeError(f"Expected dict in transcripts.pkl, got {type(transcripts)}")

    transcript_map = _build_transcript_map(transcripts)
    _attach_transcripts_to_scenes(scenes, transcript_map)

    with open(scenes_json, "w", encoding="utf-8") as f:
        json.dump(scenes, f, ensure_ascii=False, indent=2)

    vis_idx = faiss.read_index(str(db_dir / "visual.index"))
    vis_embs = vis_idx.reconstruct_n(0, vis_idx.ntotal).astype(np.float32, copy=False)

    txt_model, txt_tok = load_text_model(
        device=device,
        cache_dir=args.hf_cache_dir,
        local_files_only=args.offline_models,
    )
    txt_embs = build_all_text_embeddings(
        scenes,
        model=txt_model,
        tokenizer=txt_tok,
        device=device,
        batch_size=args.txt_batch,
    )
    save_db(scenes, vis_embs, txt_embs, str(db_dir))
    return scenes, db_dir


def run_retrieval(
    args: argparse.Namespace,
    scenes: list[dict[str, Any]],
    db_dir: Path,
    device: str,
    project_dir: Path,
) -> None:
    vis_idx, txt_idx, metadata = load_db(str(db_dir))
    vis_model, vis_proc = load_visual_model(
        device=device,
        cache_dir=args.hf_cache_dir,
        local_files_only=args.offline_models,
    )
    txt_model, txt_tok = load_text_model(
        device=device,
        cache_dir=args.hf_cache_dir,
        local_files_only=args.offline_models,
    )

    df = pd.read_csv(args.test_csv)
    missing = {args.query_col, args.query_id_col} - set(df.columns)
    if missing:
        raise ValueError(f"test.csv missing columns: {sorted(missing)}")

    top_k = max(1, args.top_k)
    candidate_k = max(top_k, args.candidate_k)
    rows_topk: list[dict[str, Any]] = []
    rows_top1: list[dict[str, Any]] = []

    for _, row in df.iterrows():
        qid = row[args.query_id_col]
        query = str(row[args.query_col])

        vis_vec = encode_visual_query(query, vis_model, vis_proc, device)
        txt_vec = encode_text_query(query, txt_model, txt_tok, device)

        _, vis_ids = search_index(vis_idx, vis_vec, candidate_k)
        _, txt_ids = search_index(txt_idx, txt_vec, candidate_k)
        hits = weighted_reciprocal_rank_fusion(
            [vis_ids.tolist(), txt_ids.tolist()],
            [args.visual_weight, args.text_weight],
        )

        best = None
        for rank, (score, fid) in enumerate(hits[:top_k], 1):
            scene = metadata[int(fid)]
            out = {
                "query_id": qid,
                "question": query,
                "rank": rank,
                "score": float(score),
                "faiss_id": int(fid),
                "video": scene["video"],
                "start_sec": float(scene["start_sec"]),
                "end_sec": float(scene["end_sec"]),
                "transcript": str(scene.get("transcript", "")),
            }
            rows_topk.append(out)
            if best is None:
                best = out

        if best is None:
            rows_top1.append({"query_id": qid, "video": "", "start_sec": 0.0, "end_sec": 0.0})
        else:
            rows_top1.append(
                {
                    "query_id": qid,
                    "video": best["video"],
                    "start_sec": best["start_sec"],
                    "end_sec": best["end_sec"],
                }
            )

    results_csv = project_dir / args.results_csv
    submission_csv = project_dir / args.submission_csv
    results_csv.parent.mkdir(parents=True, exist_ok=True)
    submission_csv.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows_topk).to_csv(results_csv, index=False)
    pd.DataFrame(rows_top1).to_csv(submission_csv, index=False)
    print(f"[retrieval] top-k saved: {results_csv}")
    print(f"[retrieval] top-1 saved: {submission_csv}")


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    device = resolve_device(args.device)
    project_dir = Path(args.project_dir).resolve()

    if not project_dir.exists():
        raise FileNotFoundError(f"project_dir not found: {project_dir}")
    project_root = _resolve_project_root(project_dir)
    _redirect_to_writable_if_needed(args, project_root)

    print(f"Project (input): {project_dir}")
    print(f"Project (root):  {project_root}")
    print(f"Device: {device}")
    print(f"Output dir: {args.output_dir}")
    print(f"DB dir:     {args.db_dir}")

    if not args.skip_build:
        run_build_vectordb(args, project_root, device)
    else:
        print("[build] skipped (--skip_build)")

    scenes, db_dir = rebuild_text_index_with_transcripts(args, project_root, device)
    print(f"[index] scenes: {len(scenes)} | db: {db_dir}")

    run_retrieval(args, scenes, db_dir, device, project_root)
    print("Done.")


if __name__ == "__main__":
    main(sys.argv[1:])
